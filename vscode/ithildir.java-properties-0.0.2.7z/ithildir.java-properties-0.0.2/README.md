# Visual Studio Code Java Properties

A port of the [TextMate](https://github.com/textmate/java.tmbundle/blob/5f4204576e13a73c9dfce525d8ced41a39d004c3/Syntaxes/JavaProperties.plist)
Java Properties (`.properties`) syntax highlighting for Visual Studio Code.