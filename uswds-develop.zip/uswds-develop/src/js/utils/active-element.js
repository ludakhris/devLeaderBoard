module.exports = (htmlDocument = document) => htmlDocument.activeElement;
