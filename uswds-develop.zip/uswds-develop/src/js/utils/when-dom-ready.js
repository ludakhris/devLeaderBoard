// TODO: remove this file in v2.0
module.exports = require('domready');
